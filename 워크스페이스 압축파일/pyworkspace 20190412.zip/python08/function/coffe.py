'''
Created on 2019. 4. 8.

@author: user
'''
'''
<함수 사용법>
1. 함수를 만들어야함 (함수 정의 definition)
2. 필요할 때마다 써야함 (함수 호출 call)
'''

def call():
    print("나를 부르셨군요....")

def call2():
    print("나도 부르셨군요.")
def call3():
    print("나도 부르셨군요333...")
def call4():
    print("나도 부르셨군요44....")



if __name__ == '__main__':
    print("여기서부터 시작입니다...")
    call()
    call2()
    call3()
    call4()
    
