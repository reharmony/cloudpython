from tkinter import messagebox
    
name = input("과목명: ")
messagebox.showinfo("과목명: ", name)

hour = input("시각: ")
messagebox.showinfo("시각: ", hour)