data1 = 100
data2 = 'python study'

print(data1)
print(data2)

print(data1, "은 타입이",type(data1))
print(data2, "는 타입이",type(data2))
