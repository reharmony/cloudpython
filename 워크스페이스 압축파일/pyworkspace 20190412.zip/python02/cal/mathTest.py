# 기본주석

# 데이터 (문자,숫자)
company = "배달의 민족";
tel = '010-1234-5678'
ssn = '3252738579'
hour = 16

# a = input("숫자1: ")
# b = input("숫자2: ")


# aa = int(input("숫자1: "))
# bb = int(input("숫자2: "))
# 
# print(aa+bb)


# 두 수를 입력받는다 

"""
num1 = int(input("첫번째 숫자: "))
num2 = int(input("두번째 숫자: "))

sum = num1 + num2
sub = num1 - num2
mul = num1 * num2
div = num1 / num2

print("%d과 %d의 합은 %d" % (num1, num2, sum))
print(num1,"과" ,num2, "의 차는", sub)
print(num1,"과" ,num2, "의 곱은", mul)
print(num1,"과" ,num2, "의 나눗셈은", div)
"""


