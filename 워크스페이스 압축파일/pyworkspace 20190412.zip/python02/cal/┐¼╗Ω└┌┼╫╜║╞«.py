# 산술연산자
print(3**4)

# 관계연산자 (비교연산자)
a=200
b=100
print(a==b)

# 논리연산자: 조건이 2개 이상인 경우, 
# 하나만 맞아도 true 또는 두개 다 맞아야 true?
# id인증부분 or pw인증부분
# id인증부분 and pw인증부분(****)

user = "root"
pw = "1234"

iId = input("id: ")
iPw = input("pw: ")



