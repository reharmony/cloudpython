
a = 100
a = a + 10
print(a)

a += 10
print(a)


# 1. a에 10을 곱해서 프린트 (누적)
a *= 10
print(a)

# 2. a에 20을 빼서 프린트 (누적)
a -= 20
print(a)

# 3. a를 3으로 나누어서 프린트 (누적)
a /= 3
print(a)


# 논리연산자 and, or, not