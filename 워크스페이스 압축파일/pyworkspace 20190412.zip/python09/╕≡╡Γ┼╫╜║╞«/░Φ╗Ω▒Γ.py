'''
Created on 2019. 4. 9.

@author: user
'''

'''
두 수를 입력받아 각각 처리해서 리턴하는
add, minus, mul, div 함수 만들기!!
'''

def add(x,y):
    return x + y
def minus(x,y):
    return x - y
def mul(x,y):
    return x * y
def div(x,y):
    return x / y



