'''
Created on 2019. 4. 9.

@author: user
'''
# 함수를 가져올 py파일의 이름을 import
import Module1

# 모듈명.함수명()
Module1.func1()
Module1.func2()
Module1.func3()



