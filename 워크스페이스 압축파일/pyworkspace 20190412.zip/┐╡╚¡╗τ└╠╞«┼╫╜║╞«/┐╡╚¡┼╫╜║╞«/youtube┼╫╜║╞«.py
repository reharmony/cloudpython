'''
Created on 2019. 4. 9.

@author: user
'''


import webbrowser
import youtube

Youtube("https://www.youtube.com/watch?v=ybhXVSAdIRE")
