# basic output: monitor
print("Hi....")
print('Hi....')

# basic input: keyboard
name = input("your name: ")
year = input("your birth year: ")
print("your input name is", name)
print("your input year is", year)


# This is result
age = 2019 - int(year) + 1
print("your age is", age)