'''
Created on 2019. 4. 10.

@author: user
'''
from productDB import delete


print("delete 실행")
name = input("name입력>> ")    
delete(name)