'''
Created on 2019. 4. 10.

@author: user
'''
from productDB import select


print("select 실행")
name = input("name입력>> ")   
select(name)