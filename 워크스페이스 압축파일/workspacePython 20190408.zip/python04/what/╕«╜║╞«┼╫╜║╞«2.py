name =["김","이","박"]

# 조원 전체 인원수 출력
print(len(name))

for i in range(0,len(name)):
    print(i, name[i])