dept = input("부서: ")
subject = input("과목: ")
old = input("지난번 성적: ")
new = input("이번 성적: ")

a = int(old)
b = int(new)
print("부서:", dept)
print("과목:", subject)
print(a + b)

