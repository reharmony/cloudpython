import os
import sys
import urllib.request
import json

client_id = "y2ojBn2tSStkUq1zVx51"
client_secret = "nKd9wpjDJZ"
encText = urllib.parse.quote("캡틴마블")
url = ("https://openapi.naver.com/v1/search/movie.json?query=%s&display=1&start=1" % encText) # json 결과
# url = "https://openapi.naver.com/v1/search/blog.xml?query=" + encText # json 결과
request = urllib.request.Request(url)
request.add_header("X-Naver-Client-Id",client_id)
request.add_header("X-Naver-Client-Secret",client_secret)
response = urllib.request.urlopen(request)
rescode = response.getcode()
if(rescode==200):
    response_body = response.read()
    decode = json.loads(response_body.decode('utf-8'))
    items = decode.get('items')    
    print(items)
   
else:
    print("Error Code:" + rescode)